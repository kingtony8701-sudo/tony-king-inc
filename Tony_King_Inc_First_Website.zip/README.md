# Tony King Inc. website — first working version

Static HTML/CSS website ready for Cloudflare Pages.

## Deploy
Create a GitHub repository, upload `index.html`, then in Cloudflare Pages choose:
- Pages
- Import existing Git repository
- Production branch: `main`
- Build command: `exit 0`
- Build output directory: `.`
